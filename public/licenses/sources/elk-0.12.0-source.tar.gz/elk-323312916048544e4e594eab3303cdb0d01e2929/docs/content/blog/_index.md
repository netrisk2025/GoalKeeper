---
title: "Blog Posts"
menu:
  main:
    identifier: "Blog"
    weight: 60
---

A place for blog posts from the ELK project team.

Recent posts:

 * [Rectpacking](./blog/posts/2022/22-08-31-rectpacking.html) *by Sören Domrös*
 * [Edge Routing with Libavoid](./blog/posts/2022/22-11-17-libavoid.html) *by Miro Spönemann*
 * [Constraining the Model](./blog/posts/2023/23-01-09-constraining-the-model.html)*by Sören Domrös*
 * [Top-down Layout: Zoom in the Layout Process](./blog/posts/2023/23-06-09-topdown-layout.html) *by Maximilian Kasperowski*
 * [Layer Unzipping](./blog/posts/2024/24-12-06-layer-unzipping.html) *by Maximilian Kasperowski*
 * [Layered](./blog/posts/2025/25-08-21-layered.html) *by Sören Domrös*
 * [Top-down Layout: Zoom in the Layout Process](./blog/posts/2023/23-06-09-topdown-layout.html) _by Maximilian Kasperowski_
 * [Layer Unzipping](./blog/posts/2024/24-12-06-layer-unzipping.html)*by Maximilian Kasperowski*
 * [Layered](./blog/posts/2025/25-08-21-layered.html) *by Sören Domrös*
 * [Node Labels](./blog/posts/2025/25-08-22-node-labels.html) *by Sören Domrös*
